#!/bin/bash

mostrar_ayuda() {
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Ayuda: $0 -help"
}

if [[ "${1:-}" == "-help" ]]; then
    mostrar_ayuda
    exit 0
fi

if [[ "$#" -ne 2 ]]; then
    mostrar_ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="${2%/}"
NOMBRE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

if [[ ! -d "$ORIGEN" ]] || ! findmnt --target "$ORIGEN" >/dev/null 2>&1; then
    echo "Error: el origen no existe o su sistema de archivos no está disponible: $ORIGEN" >&2
    exit 1
fi

if [[ "$ORIGEN" == "/www_dir" ]] && ! mountpoint -q "$ORIGEN"; then
    echo "Error: /www_dir no está montado." >&2
    exit 1
fi

if [[ ! -d "$DESTINO" ]] || ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino no existe o no está montado: $DESTINO" >&2
    exit 1
fi

if ! tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"; then
    echo "Error: no se pudo crear el backup." >&2
    exit 1
fi

echo "Backup creado: $ARCHIVO"
