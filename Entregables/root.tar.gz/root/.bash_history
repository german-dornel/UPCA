history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamect1 set-hostname TPServer
clear
hostnamect1 set-hostname TPserver
clear
hostnamectl set-hostname TPServer
hostnamectl
cat /etc/apt/sources.list
ls -l /etc/apt/sources.list.d/
apt update
ip -4 addr
ip route
cat /etc/resolv.conf
ping -c 3 10.0.2.2
ping -c 3 1.1.1.1
getent hosts cd2-fastly.deb.debian.org
clear
ip a
ip route
clear
vim /etc/network/interfaces
ip a
ip -4 addr
ip route
clear
vim /etc/network/interfaces
/etc/init.d/newtorking restart
/etc/init.d/networking restart
ping 8.8.8.8
ip -4 addr show enp0s3
getent hosts deb.debian.org
clear
ip a
cat /etc/network/interfaces
clear

apt update
cat -n /etc/apt/sources.list
clear
apt update
cat -n /etc/apt/sources.list
vim /etc/apt/sources.list
cat /etc/apt/sources.list
clear
cat /etc/apt/sources.list
apt update
apt upgrade
vim /etc/network/interfaces
vim /etc/apt/sources.list
cleasr
clear
cat /etc/apt/sources.list
apt update
apt full-upgrade
reboot
lsb_release -a
ip -4 addr show enp0s3
clear
apt-get install openssh-server
systemctl enable --now ssh
systemctl is-active ssh
systemctl is-enabled ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
sshd -t
systemctl is-active ssh
find /root -maxdepth 3 -type f\(iname '*clave*' -o -iname '*pub' -o iname 'id_*' \) print
systemctl restart virtualbox-guest-utils
clear
find /root -maxdepth 3 -type f \( -iname '*clave*' -o -iname '*pub' -o -iname 'id_*' \) -print
ls
cd Material_Adicional_TPVMCA.tar.gz
ls -l
cd Material_Adicional
cd Material_Adicional_TPVMCA.tar.gz
clear
ls
rm clave_privada.txt
rm clave_publica.pub
ls
clear
tar -xzvf archivo.tar.gz
clear
ls
tar -xzvf Material_Adicional_TPVMCA.tar.gz
ls
cd Material_Adicional_TPVMCA
ls
cd...
cd ...
cd .
cd ..
clear
mkdir -p /root/.ssh
ls
ls
ls -a
cd Material_Adicional_TPVMCA
mv /root/clave_privada.txt /root/.ssh/id.rsa
ls
clear
ls
whoami
exit
whoami
exit
ls -a
ls -la /root/.ssh
chmod 600 /root/Material_Adicional_TPVMCA/clave_privada.txt
install -m 600 /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
ls -la /root/.ssh/authorized_keys
ls /root/.ssh/authorized_keys
ls -l /root/.ssh/authorized_keys
clear
systemctl restart ssh
systemctl is-active ssh
clear
apt install apache2 php libapache2-mod-php
systemctl restart apache2
systemctl is-active apache2
php -v
apache2 -v
clear
install -o www-data -g www-data -m 644 /root/Material_Adicional_TPVMCA/index.php /var/www/html/index.php
install -o www-data -g www-data -m 644 /root/Material_Adicional_TPVMCA/logo.png /var/www/html/logo.png
ls -l /var/www/ html/index.php /var/www/html/logo.png
cat /var/www/html
ls /var/www/html
ls -l /var/www/html/index.php /var/www/html/logo.png
clear
apt install mariadb-server
systemctl is-active mariadb
mariadb --version
mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb -e "SHOW DATABASES;"
mariandb -e "USE ingenieria; SHOW TABLES;"
mariadb -e "USE ingenieria; SHOW TABLES;"
tail -n 40 /var/log/apache2/error.log
apt install php-mysql
systemctl restart apache2
php -m | grep -Ei 'mysqli|pdo_mysql'
lsblk .o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
lsblb - o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
lsblk - o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
fdisk /dev/sdc
clear
mks.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
lsblk -f /dev/sdc
mkdir -p /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h /www_dir /backup_dir
blkid /dev/sdc1 /dev/sdc2
vim /etc/fstab
mount -a
findmnt /www_dir /backup_dir
df -h /www_dir /backup_dir
grep -E 'www_dir|backup_dir' /etc/fstab
cat /proc/partitions > /opt/particion
cat /opt/particion
install -o www-data -g www-data -m 644 /root/Material_Adicional_TPVMCA/index.php
install -o www-data -g www-data -m 644 /root/Material_Adicional_TPVMCA/index.php /www_dir/index.php
install -o www-data -g www-data -m 644 /root/Material_Adicional_TPVMCA/logo.png /www_dir/logo.png
ls -l /www_dir/index.php /www_dir/logo,png
ls -l /www_dir/index.php /www_dir/logo.png
vim /etc/apache2/sites-available/000-default.conf
grep -n DocumentRoot /etc/apache2/sites-available/000-default.conf
vim /etc/apache2/apache2.conf
apache2ctl configtest
systemctl reload apache2
reboot
